package com.ust.student_management_api.student;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.time.LocalDate;
import java.util.List;

@Configuration
public class StudentConfig {
    @Bean
    CommandLineRunner commandLineRunner(StudentRepository repository) {
        return args -> {
            Student sam = new Student(
                    "CSE101",
                    "Sam Sundar",
                    LocalDate.of(2001, 10, 28),
                    Student.Gender.MALE,
                    "sam.sundar@gmail.com",
                    "Chennai, India",
                    Student.Program.BE,
                    2022,
                    Student.Department.CSE,
                    "A",
                    "9876543210"
            );

            Student jeswin = new Student(
                    "ECE102",
                    "Jeswin Sundar",
                    LocalDate.of(2001, 10, 28),
                    Student.Gender.MALE,
                    "jeswin.sundar@gmail.com",
                    "Bangalore, India",
                    Student.Program.BE,
                    2024,
                    Student.Department.ECE,
                    "B",
                    "9123456789"
            );

            repository.saveAll(List.of(sam, jeswin));
        };
    }

}

