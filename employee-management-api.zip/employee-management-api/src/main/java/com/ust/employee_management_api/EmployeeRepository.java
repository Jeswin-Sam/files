package com.ust.employee_management_api;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Query("SELECT emp FROM Employee emp WHERE emp.email = ?1")
    public Optional<Employee> findEmployeeByEmail(String email);
}
