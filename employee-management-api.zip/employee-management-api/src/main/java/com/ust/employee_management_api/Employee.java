package com.ust.employee_management_api;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.Period;

@Entity
@Table
public class Employee {

    @Id
    @SequenceGenerator(
            name = "employee_sequence",
            sequenceName = "employee_sequence",
            allocationSize = 1
    )

    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "employee_sequence"
    )
    private Long employeeId;
    private String employeeName;
    private String email;
    private LocalDate employeeDOB;
    @Transient
    private Integer employeeAge;

    public Employee(Long employeeId, String employeeName, String email, LocalDate DOB, Integer age) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.email = email;
        this.employeeDOB = DOB;
    }

    public Employee() {
    }

    public Employee(String employeeName, String email, LocalDate DOB, Integer age) {
        this.employeeName = employeeName;
        this.email = email;
        this.employeeDOB = DOB;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getEmployeeDOB() {
        return employeeDOB;
    }

    public void setEmployeeDOB(LocalDate employeeDOB) {
        this.employeeDOB = employeeDOB;
    }

    public Integer getEmployeeAge() {
        return Period.between(employeeDOB, LocalDate.now()).getYears();
    }

    public void setEmployeeAge(Integer employeeAge) {
        this.employeeAge = employeeAge;
    }
}
