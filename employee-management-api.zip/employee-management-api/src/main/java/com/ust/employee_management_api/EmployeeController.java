package com.ust.employee_management_api;

import com.ust.employee_management_api.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/employee")
public class EmployeeController {

    private final EmployeeService employeeService;

    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // Get all employees
    @GetMapping
    public ResponseEntity<ApiResponse<List<Employee>>> getAllEmployees() {
        List<Employee> employeeList = employeeService.getAllEmployees();
        ApiResponse<List<Employee>> response = new ApiResponse<>(
                "success",
                200,
                "Employee fetched successfully!",
                employeeList);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // Add new employee
    @PostMapping("/add")
    public ResponseEntity<ApiResponse<Employee>> registerNewEmployee(@RequestBody Employee employee) {
        Employee newEmployee = employeeService.addNewEmployee(employee);

        ApiResponse<Employee> response = new ApiResponse<>(
                "created",
                201,
                "New employee created!",
                newEmployee);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Delete employee by Id
    @DeleteMapping(path = "/delete/{employeeId}")
    public void deleteEmployeeById(@PathVariable Long employeeId) {
        employeeService.deleteEmployee(employeeId);
    }

    // Update employee
    @PutMapping(path = "/update/{empId}")
    public void updateEmployee(
            @PathVariable("empId") Long empId,
            @RequestParam(required = false) String empName,
            @RequestParam(required = false) String empEmail
    ) {
        employeeService.updateEmployee(empId, empName, empEmail);
    }
}
