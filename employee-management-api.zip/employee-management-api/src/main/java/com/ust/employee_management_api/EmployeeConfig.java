package com.ust.employee_management_api;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.util.List;

@Configuration
public class EmployeeConfig {
    @Bean
    CommandLineRunner commandLineRunner(EmployeeRepository repository) {
        return args -> {

            Employee sam = new Employee(
                    "Sam",
                    "sam.sundar@gmail.com",
                    LocalDate.of(2001, 10, 28),
                    23
            );

            Employee jeswin = new Employee(
                    "Jeswin",
                    "jeswin.sundar@gmail.com",
                    LocalDate.of(2001, 10, 28),
                    23
            );

            repository.saveAll(List.of(jeswin, sam));
        };
    }
}
