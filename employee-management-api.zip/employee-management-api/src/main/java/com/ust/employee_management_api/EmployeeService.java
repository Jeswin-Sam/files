package com.ust.employee_management_api;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    @Autowired
    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // Get all employees
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Add new employee
    public Employee addNewEmployee(Employee employee) {
        Optional<Employee> employeeByEmail = employeeRepository.findEmployeeByEmail(employee.getEmail());
        if (employeeByEmail.isPresent()) {
            throw new IllegalStateException("Email already exists!");
        }
        return employeeRepository.save(employee);
    }

    // Delete employee by Id
    public void deleteEmployee(Long empId) {
        boolean isExistingEmployee = employeeRepository.existsById(empId);
        if (!isExistingEmployee)
            throw new IllegalStateException("Employee with id " + empId + " does not exist.");
        employeeRepository.deleteById(empId);
    }

    @Transactional
    public void updateEmployee(Long empId, String empName, String empEmail) {

        Employee employee = employeeRepository.findById(empId)
                .orElseThrow(
                        () -> new IllegalStateException("Employee with id " + empId + " does not exist.")
                );

        if (empName != null && !empName.isEmpty()
                && !Objects.equals(employee.getEmployeeName(), empName)) {
            employee.setEmployeeName(empName);
        }

        if (empEmail != null && !empEmail.isEmpty()
                && !Objects.equals(employee.getEmail(), empEmail)) {

            Optional<Employee> existingEmployeeWithSameEmail = employeeRepository.findEmployeeByEmail(empEmail);
            if (existingEmployeeWithSameEmail.isPresent()) // Check if any other employee has the same email
                throw new IllegalStateException("Email already exists");

            employee.setEmail(empEmail);
        }
    }
}


